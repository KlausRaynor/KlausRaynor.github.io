describe('PIXI', function () {
    it('exists', function () {
        expect(PIXI)
            .to.be.an('object');
    });
});
